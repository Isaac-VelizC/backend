<div>
    <div class="iq-navbar-header" style="height: 170px;">
        <div class="container-fluid iq-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="flex-wrap d-flex justify-content-between align-items-center text-black">
                        <div>
                            <h1>Reporte de Pagos</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="conatiner-fluid content-inner mt-n5 py-0">
        <div class="row">
            <div class="col-md-12">
                <div class="row row-cols-1">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="text-center">
                                            <h4 class="card-title mb-0">REPORTES DE PAGOS</h4>
                                        </div>
                                    </div>
                                    <hr>
                                    <form class="form" wire:submit.prevent='searchPagos'>
                                        <div class="row">
                                            <div class="col">
                                                <select wire:model='selectEstudiante' class="form-select">
                                                    <option value="" selected>Seleccionar Estudiante</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($est->id); ?>"><?php echo e($est->persona->nombre); ?> <?php echo e($est->persona->ap_paterno); ?> <?php echo e($est->persona->ap_materno); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="col">
                                                <select class="form-select" wire:model="selectedMonth">
                                                    <option value="">Seleccionar Mes</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>"><?php echo e($month); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                            </div>
                                            <div class="col">
                                                <select class="form-select" wire:model="selectedYear">
                                                    <option value="">Seleccionar Año</option>
                                                    <!--[if BLOCK]><![endif]--><?php for($year = $startYear; $year <= $endYear; $year++): ?>
                                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                                    <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                            </div>
                                            <div class="col">
                                                <select wire:model='selectEstado' class="form-select">
                                                    <option value="" selected>Seleccionar Estado</option>
                                                    <option value="0">Pendientes</option>
                                                    <option value="1">Pagado</option>
                                                </select>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="text-center">
                                                <button type="button" class="btn btn-primary btn-sm" wire:click='resetForm'>Cancelar</button>
                                                <button type="submit" class="btn btn-secondary btn-sm">Buscar</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                <table id="datatable" class="table table-striped" data-toggle="data-table">
                                    <thead>
                                        <tr>
                                            <th>Estudiante</th>
                                            <th>Monto</th>
                                            <th>Mes</th>
                                            <th>Año</th>
                                            <th>Fecha</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--[if BLOCK]><![endif]--><?php if($resultados && count($resultados) > 0): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->estudiante->persona->nombre); ?> <?php echo e($item->estudiante->persona->ap_paterno); ?> <?php echo e($item->estudiante->persona->ap_materno); ?></td>
                                                    <td><?php echo e($item->monto); ?>Bs.</td>
                                                    <td><?php echo e(\Carbon\Carbon::create()->month($item->mes)->locale('es_ES')->monthName); ?></td>
                                                    <td><?php echo e($item->anio); ?></td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($item->fecha)->locale('es_ES')->isoFormat('LL')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\backend\resources\views/livewire/admin/informe/pagos-reportes.blade.php ENDPATH**/ ?>