<div class="modal fade" id="formIngrediente" tabindex="-1" aria-labelledby="formIngrediente" aria-hidden="true">
    <div class="modal-dialog">
       <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formIngrediente">Ingistrar nuevo ingrediente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?php echo e(route('new.ingrediente.db')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="col-sm-12 col-lg-12">
                        <div class="row">
                            <div class="form-group">
                                <label class="form-label" for="fname">Nombre del Ingrediente:</label>
                                <input type="text" class="form-control" id="fname" name="nombre" value="<?php echo e(old('nombre')); ?>" placeholder="Nombre" required>
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="type_select">Seleccionar Tipo</label>
                                <select class="form-select" id="type_select" name="tipo" required>
                                  <option value="<?php echo e(old('tipo')); ?>" disabled selected>Seleccionar</option>
                                  <?php if($types->count() > 0): ?>
                                      <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($type->id); ?>"><?php echo e($type->nombre); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                      <option value="">Vacio</option>
                                  <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button class="btn btn-danger" type="submit">Guardar</button>
                </div>
            </form>
       </div>
    </div>
 </div><?php /**PATH D:\xampp\htdocs\backend\resources\views/admin/recetas/ingredientes/modal_create.blade.php ENDPATH**/ ?>