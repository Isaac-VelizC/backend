<?php $__env->startSection('content'); ?>
   <div class="row m-0 align-items-center bg-gray-300 vh-100">            
      <div class="col-md-6">
         <div class="row justify-content-center">
            <div class="col-md-10">
               <div class=" px-sm-2 px-4 px-lg-5">
                  <div class=" text-center navbar-brand mb-3 py-4">
                     <img src="<?php echo e(asset('img/igla-logo.png')); ?>" alt="log" width="300">
                  </div>
                  <p class="text-center">Inicie sesión para mantenerse conectado.</p>
                  <form method="POST" action="<?php echo e(route('login')); ?>">
                     <?php echo csrf_field(); ?>
                     <div class="row">
                        <div class="col-lg-12">
                           <div class="form-group">
                              <label for="email" class="form-label">Usuario</label>
                              <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required aria-describedby="email" autocomplete="email" autofocus>
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                 </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg-12">
                           <div class="form-group">
                              <label for="password" class="form-label">Contraseña</label>
                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" aria-describedby="password" required autocomplete="current-password">
                           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                 </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg-12 d-flex justify-content-between">
                           <div class="form-check mb-3">
                              <input class="form-check-input" type="checkbox" name="remember" id="customCheck1" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                              <label class="form-check-label" for="customCheck1">Recuerdame</label>
                           </div>
                           <?php if(Route::has('password.request')): ?>
                                 <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('¿Olvidaste la contraseña?')); ?>

                                 </a>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="d-flex justify-content-center mt-4">
                        <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-6 d-md-block d-none p-0 vh-100 overflow-hidden">
         <img src="<?php echo e(asset('assets/images/auth/login.jpg')); ?>" class="gradient-main rounded-5" alt="images">
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>