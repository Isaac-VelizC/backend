<?php $__env->startSection('content'); ?>

<div class="position-relative iq-banner">
    <div class="iq-navbar-header" style="height: 150px;">
        <div class="container-fluid iq-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="flex-wrap d-flex justify-content-between align-items-center text-black">
                        <div>
                            <h4><?php echo e(Breadcrumbs::render('Inventario.list')); ?></h4>
                        </div>
                        <div>
                            <a class="btn btn-link" href="<?php echo e(route('admin.inventario.historial')); ?>">
                                <i class="bi bi-list-columns"></i> Historial
                            </a>
                            <a class="btn btn-primary" href="<?php echo e(route('admin.gestion.inventario.form')); ?>" >
                                <i class="bi bi-bag-plus"></i> Nuevo
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="iq-header-img">
            <img src="<?php echo e(asset('img/fondo1.jpg')); ?>" alt="header" class="img-fluid w-100 h-100 animated-scaleX">
        </div>
    </div>
 </div>

<div class="conatiner-fluid content-inner mt-n5 py-0">
     <?php if(session('success')): ?>
         <div id="myAlert" class="alert alert-left alert-success alert-dismissible fade show mb-3 alert-fade" role="alert">
             <span><?php echo e(session('success')); ?></span>
             <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>
     <?php endif; ?>
     <?php if(session('error')): ?>
         <div id="myAlert" class="alert alert-left alert-danger alert-dismissible fade show mb-3 alert-fade" role="alert">
             <span><?php echo e(session('error')); ?></span>
             <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>
     <?php endif; ?>
    <div class="row">
       <div class="col-sm-12">
          <div class="card">
             <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-striped" data-toggle="data-table">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Nombre</th>
                                <th>Cantidad</th>
                                <th>Tipo</th>
                                <th>Modificación</th>
                                <th>Estado</th>
                                <th></th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        <tbody>
                            <?php if(count($ingredientes) > 0): ?>
                                <?php $__currentLoopData = $ingredientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($item->ingrediente->nombre); ?></td>
                                        <td><?php echo e($item->cantidad); ?> <?php echo e($item->unidad_media); ?></td>
                                        <td><?php echo e($item->ingrediente->tipo ? $item->ingrediente->tipo->nombre : 'No tiene'); ?></td>
                                        <td><?php echo e($item->fecha_modificacion); ?></td>
                                        <td><?php echo e($item->estado); ?></td>
                                        <td>
                                            <div class="flex align-items-center list-user-action">
                                                <a class="btn btn-sm btn-icon btn-light" data-bs-placement="top" data-bs-toggle="modal" data-bs-target="#addCantidad<?php echo e($item->id); ?>">
                                                    <i class="bi bi-plus-circle-dotted"></i>
                                                </a>
                                                <a class="btn btn-sm btn-icon btn-primary" data-bs-placement="top" href="<?php echo e(route('admin.gestion.inventario.edit', $item->id)); ?>">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a class="btn btn-sm btn-icon btn-danger" data-bs-placement="top" data-bs-toggle="modal" data-bs-target="#deleteConfirm<?php echo e($item->id); ?>">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php echo $__env->make('admin.inventario.modal_confirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
             </div>
          </div>
       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\backend\resources\views/admin/inventario/index.blade.php ENDPATH**/ ?>